USE NerdyGadgets;

CREATE FULLTEXT INDEX zoekartikel ON stockitems(stockitemname, searchdetails, marketingcomments);